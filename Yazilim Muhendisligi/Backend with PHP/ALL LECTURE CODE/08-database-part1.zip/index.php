<?php
    require_once "./db.php" ;
   // echo "Connected" ;
   
   if ( !empty($_POST)) {
       extract($_POST) ;
       // Validate All Form Data
       // Title : not empty
       // Price : float number, preg_match('/^\d{1,4}\.\d{1,2}$/', $price)
       // Launch: YYYY-MM?-DD?  preg_match('/^\d{4}-\d\d?-\d\d?$/', $launch)
       try {
            $sql = "insert into games (title, price, launch) values (?, ?, ?)" ;
            $rs = $db->prepare($sql) ;
            $rs->execute([$title, $price, $launch]) ;
        } catch( PDOException $ex) {
            $errMsg = "Insert Fail" ; 
        }
   } else if (isset($_GET["delete"])) {
       $id = $_GET["delete"] ;
       try {
           $rs = $db->prepare("delete from games where id = :id") ;
           $rs->execute(["id" => $id]) ;
           if ( $rs->rowCount() == 0) $errMsg = "Already deleted" ;
       } catch(PDOException $ex) {
           $errMsg = "Delete Fail" ;
       }
   }



   try {
      $rs = $db->query("select * from games") ;
      // Convert PDOStatement/ResultSet object to PHP Array.
      $games = $rs->fetchAll(PDO::FETCH_ASSOC) ;
   } catch( PDOException $ex) {
       echo "<p>", $ex->getMessage() ,"</p>" ;
   }


?>

<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0"/>
    <title>Title of the document</title>
    <link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/materialize/1.0.0/css/materialize.min.css">
    <script src="https://code.jquery.com/jquery-3.2.1.min.js" integrity="sha256-hwg4gsxgFZhOsEEamdOYGBf13FyQuiTwlAQgxVSNgt4=" crossorigin="anonymous"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/materialize/1.0.0/js/materialize.min.js"></script>
    <style>
    </style>
  </head>
  <body>
  <div class="card-panel teal lighten-2 white-text">
     <h4 class="center">List of Games</h4>
  </div>

  <div class="container">
    <form action="" method="post">
        <table>
           <tr>
               <td colspan="2">
                  <div class="input-field">
                    <input name="title" id="title" type="text" class="validate">
                    <label for="title">Title</label>
                  </div>
               </td>
               <td>
                  <div class="input-field">
                    <input name="price" id="price" type="text" class="validate">
                    <label for="price">Price</label>
                  </div>
               </td>
               <td>
                  <input name="launch" type="text" class="datepicker">
               </td>
               <td>
                  <button class="btn waves-effect waves-light" type="submit" name="action">
                    <i class="material-icons">add</i>
                  </button>
               </td>
           </tr>

            <tr>
                <th width="5%">ID</th>
                <th width="55%">TITLE</th>
                <th width="15%">PRICE</th>
                <th width="20%">LAUNCH</th>
                <th width="5%">Ops</th>
            </tr>
            <?php foreach( $games as $game) : ?>
            <tr>
                <td><?= $game["id"] ?></td>
                <td><?= $game["title"] ?></td>
                <td>$ <?= $game["price"] ?></td>
                <td><?= $game["launch"] ?></td>
                <td>
                    <a href="?delete=<?= $game["id"] ?>" class="btn-small"><i class="material-icons">delete</i></a>
                </td>
            </tr>
            <?php endforeach ?>
        </table>
        <?= "<p>Rows : " . $rs->rowCount() . "</p>"  ?>
    </form>
  
  
  </div>

  <?php
       if ( isset($errMsg)) {
           echo "<script> M.toast({html: '$errMsg', classes: 'red white-text'}) ; </script>" ;
       }

  ?>

  <script>
    $(function(){
        $('.datepicker').datepicker({format: "yyyy-mm-dd"});
    })
  </script>
  </body>
</html>