Import Game Data:

1. Using phpmyadmin ( http://localhost/phpmyadmin )
2. Select mysql database, and type username:root password:  (leave it empty)
3. Select Server Choice as "MySQL"
4. Note the port number of MySQL
5. Select "Databases", at the top of right side.
6. Create a Database as "gamesdb"
7. Select "Import" and import "games.sql" file.

Using PDO:

1. In dsn, use the port number of your mysql server.