(SELECT is_ys.user.user_id,is_ys.user.user_fn, is_ys.user.user_ln, is_ys.restaurant.restaurant_name, is_ys.order.order_dt
FROM is_ys.user, is_ys.restaurant, is_ys.order
WHERE is_ys.user.user_id = is_ys.order.user_id AND is_ys.restaurant.restaurant_id = is_ys.order.restaurant_id AND is_ys.user.user_id = 5
ORDER BY is_ys.order.order_dt DESC
LIMIT 5)
UNION ALL
(SELECT is_ys.user.user_id,is_ys.user.user_fn, is_ys.user.user_ln, is_ys.restaurant.restaurant_name, is_ys.order.order_dt
FROM is_ys.user, is_ys.restaurant, is_ys.order
WHERE is_ys.user.user_id = is_ys.order.user_id AND is_ys.restaurant.restaurant_id = is_ys.order.restaurant_id AND is_ys.user.user_id = 1
ORDER BY is_ys.order.order_dt DESC
LIMIT 5)
UNION ALL
(SELECT is_ys.user.user_id,is_ys.user.user_fn, is_ys.user.user_ln, is_ys.restaurant.restaurant_name, is_ys.order.order_dt
FROM is_ys.user, is_ys.restaurant, is_ys.order
WHERE is_ys.user.user_id = is_ys.order.user_id AND is_ys.restaurant.restaurant_id = is_ys.order.restaurant_id AND is_ys.user.user_id = 2
ORDER BY is_ys.order.order_dt DESC
LIMIT 5)
UNION ALL
(SELECT is_ys.user.user_id,is_ys.user.user_fn, is_ys.user.user_ln, is_ys.restaurant.restaurant_name, is_ys.order.order_dt
FROM is_ys.user, is_ys.restaurant, is_ys.order
WHERE is_ys.user.user_id = is_ys.order.user_id AND is_ys.restaurant.restaurant_id = is_ys.order.restaurant_id AND is_ys.user.user_id = 3
ORDER BY is_ys.order.order_dt DESC
LIMIT 5)
UNION ALL
(SELECT is_ys.user.user_id,is_ys.user.user_fn, is_ys.user.user_ln, is_ys.restaurant.restaurant_name, is_ys.order.order_dt
FROM is_ys.user, is_ys.restaurant, is_ys.order
WHERE is_ys.user.user_id = is_ys.order.user_id AND is_ys.restaurant.restaurant_id = is_ys.order.restaurant_id AND is_ys.user.user_id = 4
ORDER BY is_ys.order.order_dt DESC
LIMIT 5)
UNION ALL
(SELECT is_ys.user.user_id,is_ys.user.user_fn, is_ys.user.user_ln, is_ys.restaurant.restaurant_name, is_ys.order.order_dt
FROM is_ys.user, is_ys.restaurant, is_ys.order
WHERE is_ys.user.user_id = is_ys.order.user_id AND is_ys.restaurant.restaurant_id = is_ys.order.restaurant_id AND is_ys.user.user_id = 6
ORDER BY is_ys.order.order_dt DESC
LIMIT 5)
UNION ALL
(SELECT is_ys.user.user_id,is_ys.user.user_fn, is_ys.user.user_ln, is_ys.restaurant.restaurant_name, is_ys.order.order_dt
FROM is_ys.user, is_ys.restaurant, is_ys.order
WHERE is_ys.user.user_id = is_ys.order.user_id AND is_ys.restaurant.restaurant_id = is_ys.order.restaurant_id AND is_ys.user.user_id = 7
ORDER BY is_ys.order.order_dt DESC
LIMIT 5)
UNION ALL
(SELECT is_ys.user.user_id,is_ys.user.user_fn, is_ys.user.user_ln, is_ys.restaurant.restaurant_name, is_ys.order.order_dt
FROM is_ys.user, is_ys.restaurant, is_ys.order
WHERE is_ys.user.user_id = is_ys.order.user_id AND is_ys.restaurant.restaurant_id = is_ys.order.restaurant_id AND is_ys.user.user_id = 8
ORDER BY is_ys.order.order_dt DESC
LIMIT 5)
UNION ALL
(SELECT is_ys.user.user_id,is_ys.user.user_fn, is_ys.user.user_ln, is_ys.restaurant.restaurant_name, is_ys.order.order_dt
FROM is_ys.user, is_ys.restaurant, is_ys.order
WHERE is_ys.user.user_id = is_ys.order.user_id AND is_ys.restaurant.restaurant_id = is_ys.order.restaurant_id AND is_ys.user.user_id = 9
ORDER BY is_ys.order.order_dt DESC
LIMIT 5)
UNION ALL
(SELECT is_ys.user.user_id,is_ys.user.user_fn, is_ys.user.user_ln, is_ys.restaurant.restaurant_name, is_ys.order.order_dt
FROM is_ys.user, is_ys.restaurant, is_ys.order
WHERE is_ys.user.user_id = is_ys.order.user_id AND is_ys.restaurant.restaurant_id = is_ys.order.restaurant_id AND is_ys.user.user_id = 10
ORDER BY is_ys.order.order_dt DESC
LIMIT 5)
UNION ALL
(SELECT is_ys.user.user_id,is_ys.user.user_fn, is_ys.user.user_ln, is_ys.restaurant.restaurant_name, is_ys.order.order_dt
FROM is_ys.user, is_ys.restaurant, is_ys.order
WHERE is_ys.user.user_id = is_ys.order.user_id AND is_ys.restaurant.restaurant_id = is_ys.order.restaurant_id AND is_ys.user.user_id = 11
ORDER BY is_ys.order.order_dt DESC
LIMIT 5)
UNION ALL
(SELECT is_ys.user.user_id,is_ys.user.user_fn, is_ys.user.user_ln, is_ys.restaurant.restaurant_name, is_ys.order.order_dt
FROM is_ys.user, is_ys.restaurant, is_ys.order
WHERE is_ys.user.user_id = is_ys.order.user_id AND is_ys.restaurant.restaurant_id = is_ys.order.restaurant_id AND is_ys.user.user_id = 12
ORDER BY is_ys.order.order_dt DESC
LIMIT 5)
UNION ALL
(SELECT is_ys.user.user_id,is_ys.user.user_fn, is_ys.user.user_ln, is_ys.restaurant.restaurant_name, is_ys.order.order_dt
FROM is_ys.user, is_ys.restaurant, is_ys.order
WHERE is_ys.user.user_id = is_ys.order.user_id AND is_ys.restaurant.restaurant_id = is_ys.order.restaurant_id AND is_ys.user.user_id = 13
ORDER BY is_ys.order.order_dt DESC
LIMIT 5)
UNION ALL
(SELECT is_ys.user.user_id,is_ys.user.user_fn, is_ys.user.user_ln, is_ys.restaurant.restaurant_name, is_ys.order.order_dt
FROM is_ys.user, is_ys.restaurant, is_ys.order
WHERE is_ys.user.user_id = is_ys.order.user_id AND is_ys.restaurant.restaurant_id = is_ys.order.restaurant_id AND is_ys.user.user_id = 14
ORDER BY is_ys.order.order_dt DESC
LIMIT 5)
UNION ALL
(SELECT is_ys.user.user_id,is_ys.user.user_fn, is_ys.user.user_ln, is_ys.restaurant.restaurant_name, is_ys.order.order_dt
FROM is_ys.user, is_ys.restaurant, is_ys.order
WHERE is_ys.user.user_id = is_ys.order.user_id AND is_ys.restaurant.restaurant_id = is_ys.order.restaurant_id AND is_ys.user.user_id = 15
ORDER BY is_ys.order.order_dt DESC
LIMIT 5)
UNION ALL
(SELECT is_ys.user.user_id,is_ys.user.user_fn, is_ys.user.user_ln, is_ys.restaurant.restaurant_name, is_ys.order.order_dt
FROM is_ys.user, is_ys.restaurant, is_ys.order
WHERE is_ys.user.user_id = is_ys.order.user_id AND is_ys.restaurant.restaurant_id = is_ys.order.restaurant_id AND is_ys.user.user_id = 16
ORDER BY is_ys.order.order_dt DESC
LIMIT 5)
UNION ALL
(SELECT is_ys.user.user_id,is_ys.user.user_fn, is_ys.user.user_ln, is_ys.restaurant.restaurant_name, is_ys.order.order_dt
FROM is_ys.user, is_ys.restaurant, is_ys.order
WHERE is_ys.user.user_id = is_ys.order.user_id AND is_ys.restaurant.restaurant_id = is_ys.order.restaurant_id AND is_ys.user.user_id = 17
ORDER BY is_ys.order.order_dt DESC
LIMIT 5)
UNION ALL
(SELECT is_ys.user.user_id,is_ys.user.user_fn, is_ys.user.user_ln, is_ys.restaurant.restaurant_name, is_ys.order.order_dt
FROM is_ys.user, is_ys.restaurant, is_ys.order
WHERE is_ys.user.user_id = is_ys.order.user_id AND is_ys.restaurant.restaurant_id = is_ys.order.restaurant_id AND is_ys.user.user_id = 18
ORDER BY is_ys.order.order_dt DESC
LIMIT 5)
UNION ALL
(SELECT is_ys.user.user_id,is_ys.user.user_fn, is_ys.user.user_ln, is_ys.restaurant.restaurant_name, is_ys.order.order_dt
FROM is_ys.user, is_ys.restaurant, is_ys.order
WHERE is_ys.user.user_id = is_ys.order.user_id AND is_ys.restaurant.restaurant_id = is_ys.order.restaurant_id AND is_ys.user.user_id = 19
ORDER BY is_ys.order.order_dt DESC
LIMIT 5)
UNION ALL
(SELECT is_ys.user.user_id,is_ys.user.user_fn, is_ys.user.user_ln, is_ys.restaurant.restaurant_name, is_ys.order.order_dt
FROM is_ys.user, is_ys.restaurant, is_ys.order
WHERE is_ys.user.user_id = is_ys.order.user_id AND is_ys.restaurant.restaurant_id = is_ys.order.restaurant_id AND is_ys.user.user_id = 20
ORDER BY is_ys.order.order_dt DESC
LIMIT 5)
UNION ALL
(SELECT is_ys.user.user_id,is_ys.user.user_fn, is_ys.user.user_ln, is_ys.restaurant.restaurant_name, is_ys.order.order_dt
FROM is_ys.user, is_ys.restaurant, is_ys.order
WHERE is_ys.user.user_id = is_ys.order.user_id AND is_ys.restaurant.restaurant_id = is_ys.order.restaurant_id AND is_ys.user.user_id = 21
ORDER BY is_ys.order.order_dt DESC
LIMIT 5)
UNION ALL
(SELECT is_ys.user.user_id,is_ys.user.user_fn, is_ys.user.user_ln, is_ys.restaurant.restaurant_name, is_ys.order.order_dt
FROM is_ys.user, is_ys.restaurant, is_ys.order
WHERE is_ys.user.user_id = is_ys.order.user_id AND is_ys.restaurant.restaurant_id = is_ys.order.restaurant_id AND is_ys.user.user_id = 22
ORDER BY is_ys.order.order_dt DESC
LIMIT 5)
UNION ALL
(SELECT is_ys.user.user_id,is_ys.user.user_fn, is_ys.user.user_ln, is_ys.restaurant.restaurant_name, is_ys.order.order_dt
FROM is_ys.user, is_ys.restaurant, is_ys.order
WHERE is_ys.user.user_id = is_ys.order.user_id AND is_ys.restaurant.restaurant_id = is_ys.order.restaurant_id AND is_ys.user.user_id = 23
ORDER BY is_ys.order.order_dt DESC
LIMIT 5)
UNION ALL
(SELECT is_ys.user.user_id,is_ys.user.user_fn, is_ys.user.user_ln, is_ys.restaurant.restaurant_name, is_ys.order.order_dt
FROM is_ys.user, is_ys.restaurant, is_ys.order
WHERE is_ys.user.user_id = is_ys.order.user_id AND is_ys.restaurant.restaurant_id = is_ys.order.restaurant_id AND is_ys.user.user_id = 24
ORDER BY is_ys.order.order_dt DESC
LIMIT 5)
UNION ALL
(SELECT is_ys.user.user_id,is_ys.user.user_fn, is_ys.user.user_ln, is_ys.restaurant.restaurant_name, is_ys.order.order_dt
FROM is_ys.user, is_ys.restaurant, is_ys.order
WHERE is_ys.user.user_id = is_ys.order.user_id AND is_ys.restaurant.restaurant_id = is_ys.order.restaurant_id AND is_ys.user.user_id = 25
ORDER BY is_ys.order.order_dt DESC
LIMIT 5)
UNION ALL
(SELECT is_ys.user.user_id,is_ys.user.user_fn, is_ys.user.user_ln, is_ys.restaurant.restaurant_name, is_ys.order.order_dt
FROM is_ys.user, is_ys.restaurant, is_ys.order
WHERE is_ys.user.user_id = is_ys.order.user_id AND is_ys.restaurant.restaurant_id = is_ys.order.restaurant_id AND is_ys.user.user_id = 26
ORDER BY is_ys.order.order_dt DESC
LIMIT 5)
UNION ALL
(SELECT is_ys.user.user_id,is_ys.user.user_fn, is_ys.user.user_ln, is_ys.restaurant.restaurant_name, is_ys.order.order_dt
FROM is_ys.user, is_ys.restaurant, is_ys.order
WHERE is_ys.user.user_id = is_ys.order.user_id AND is_ys.restaurant.restaurant_id = is_ys.order.restaurant_id AND is_ys.user.user_id = 27
ORDER BY is_ys.order.order_dt DESC
LIMIT 5)
UNION ALL
(SELECT is_ys.user.user_id,is_ys.user.user_fn, is_ys.user.user_ln, is_ys.restaurant.restaurant_name, is_ys.order.order_dt
FROM is_ys.user, is_ys.restaurant, is_ys.order
WHERE is_ys.user.user_id = is_ys.order.user_id AND is_ys.restaurant.restaurant_id = is_ys.order.restaurant_id AND is_ys.user.user_id = 28
ORDER BY is_ys.order.order_dt DESC
LIMIT 5)
UNION ALL
(SELECT is_ys.user.user_id,is_ys.user.user_fn, is_ys.user.user_ln, is_ys.restaurant.restaurant_name, is_ys.order.order_dt
FROM is_ys.user, is_ys.restaurant, is_ys.order
WHERE is_ys.user.user_id = is_ys.order.user_id AND is_ys.restaurant.restaurant_id = is_ys.order.restaurant_id AND is_ys.user.user_id = 29
ORDER BY is_ys.order.order_dt DESC
LIMIT 5)
UNION ALL
(SELECT is_ys.user.user_id,is_ys.user.user_fn, is_ys.user.user_ln, is_ys.restaurant.restaurant_name, is_ys.order.order_dt
FROM is_ys.user, is_ys.restaurant, is_ys.order
WHERE is_ys.user.user_id = is_ys.order.user_id AND is_ys.restaurant.restaurant_id = is_ys.order.restaurant_id AND is_ys.user.user_id = 30
ORDER BY is_ys.order.order_dt DESC
LIMIT 5)
UNION ALL
(SELECT is_ys.user.user_id,is_ys.user.user_fn, is_ys.user.user_ln, is_ys.restaurant.restaurant_name, is_ys.order.order_dt
FROM is_ys.user, is_ys.restaurant, is_ys.order
WHERE is_ys.user.user_id = is_ys.order.user_id AND is_ys.restaurant.restaurant_id = is_ys.order.restaurant_id AND is_ys.user.user_id = 31
ORDER BY is_ys.order.order_dt DESC
LIMIT 5)
UNION ALL
(SELECT is_ys.user.user_id,is_ys.user.user_fn, is_ys.user.user_ln, is_ys.restaurant.restaurant_name, is_ys.order.order_dt
FROM is_ys.user, is_ys.restaurant, is_ys.order
WHERE is_ys.user.user_id = is_ys.order.user_id AND is_ys.restaurant.restaurant_id = is_ys.order.restaurant_id AND is_ys.user.user_id = 32
ORDER BY is_ys.order.order_dt DESC
LIMIT 5)
UNION ALL
(SELECT is_ys.user.user_id,is_ys.user.user_fn, is_ys.user.user_ln, is_ys.restaurant.restaurant_name, is_ys.order.order_dt
FROM is_ys.user, is_ys.restaurant, is_ys.order
WHERE is_ys.user.user_id = is_ys.order.user_id AND is_ys.restaurant.restaurant_id = is_ys.order.restaurant_id AND is_ys.user.user_id = 33
ORDER BY is_ys.order.order_dt DESC
LIMIT 5)
UNION ALL
(SELECT is_ys.user.user_id,is_ys.user.user_fn, is_ys.user.user_ln, is_ys.restaurant.restaurant_name, is_ys.order.order_dt
FROM is_ys.user, is_ys.restaurant, is_ys.order
WHERE is_ys.user.user_id = is_ys.order.user_id AND is_ys.restaurant.restaurant_id = is_ys.order.restaurant_id AND is_ys.user.user_id = 34
ORDER BY is_ys.order.order_dt DESC
LIMIT 5)
UNION ALL
(SELECT is_ys.user.user_id,is_ys.user.user_fn, is_ys.user.user_ln, is_ys.restaurant.restaurant_name, is_ys.order.order_dt
FROM is_ys.user, is_ys.restaurant, is_ys.order
WHERE is_ys.user.user_id = is_ys.order.user_id AND is_ys.restaurant.restaurant_id = is_ys.order.restaurant_id AND is_ys.user.user_id = 35
ORDER BY is_ys.order.order_dt DESC
LIMIT 5)
UNION ALL
(SELECT is_ys.user.user_id,is_ys.user.user_fn, is_ys.user.user_ln, is_ys.restaurant.restaurant_name, is_ys.order.order_dt
FROM is_ys.user, is_ys.restaurant, is_ys.order
WHERE is_ys.user.user_id = is_ys.order.user_id AND is_ys.restaurant.restaurant_id = is_ys.order.restaurant_id AND is_ys.user.user_id = 36
ORDER BY is_ys.order.order_dt DESC
LIMIT 5)
UNION ALL
(SELECT is_ys.user.user_id,is_ys.user.user_fn, is_ys.user.user_ln, is_ys.restaurant.restaurant_name, is_ys.order.order_dt
FROM is_ys.user, is_ys.restaurant, is_ys.order
WHERE is_ys.user.user_id = is_ys.order.user_id AND is_ys.restaurant.restaurant_id = is_ys.order.restaurant_id AND is_ys.user.user_id = 37
ORDER BY is_ys.order.order_dt DESC
LIMIT 5)
UNION ALL
(SELECT is_ys.user.user_id,is_ys.user.user_fn, is_ys.user.user_ln, is_ys.restaurant.restaurant_name, is_ys.order.order_dt
FROM is_ys.user, is_ys.restaurant, is_ys.order
WHERE is_ys.user.user_id = is_ys.order.user_id AND is_ys.restaurant.restaurant_id = is_ys.order.restaurant_id AND is_ys.user.user_id = 38
ORDER BY is_ys.order.order_dt DESC
LIMIT 5)
UNION ALL
(SELECT is_ys.user.user_id,is_ys.user.user_fn, is_ys.user.user_ln, is_ys.restaurant.restaurant_name, is_ys.order.order_dt
FROM is_ys.user, is_ys.restaurant, is_ys.order
WHERE is_ys.user.user_id = is_ys.order.user_id AND is_ys.restaurant.restaurant_id = is_ys.order.restaurant_id AND is_ys.user.user_id = 39
ORDER BY is_ys.order.order_dt DESC
LIMIT 5)
UNION ALL
(SELECT is_ys.user.user_id,is_ys.user.user_fn, is_ys.user.user_ln, is_ys.restaurant.restaurant_name, is_ys.order.order_dt
FROM is_ys.user, is_ys.restaurant, is_ys.order
WHERE is_ys.user.user_id = is_ys.order.user_id AND is_ys.restaurant.restaurant_id = is_ys.order.restaurant_id AND is_ys.user.user_id = 40
ORDER BY is_ys.order.order_dt DESC
LIMIT 5)
UNION ALL
(SELECT is_ys.user.user_id,is_ys.user.user_fn, is_ys.user.user_ln, is_ys.restaurant.restaurant_name, is_ys.order.order_dt
FROM is_ys.user, is_ys.restaurant, is_ys.order
WHERE is_ys.user.user_id = is_ys.order.user_id AND is_ys.restaurant.restaurant_id = is_ys.order.restaurant_id AND is_ys.user.user_id = 41
ORDER BY is_ys.order.order_dt DESC
LIMIT 5)
UNION ALL
(SELECT is_ys.user.user_id,is_ys.user.user_fn, is_ys.user.user_ln, is_ys.restaurant.restaurant_name, is_ys.order.order_dt
FROM is_ys.user, is_ys.restaurant, is_ys.order
WHERE is_ys.user.user_id = is_ys.order.user_id AND is_ys.restaurant.restaurant_id = is_ys.order.restaurant_id AND is_ys.user.user_id = 42
ORDER BY is_ys.order.order_dt DESC
LIMIT 5)
UNION ALL
(SELECT is_ys.user.user_id,is_ys.user.user_fn, is_ys.user.user_ln, is_ys.restaurant.restaurant_name, is_ys.order.order_dt
FROM is_ys.user, is_ys.restaurant, is_ys.order
WHERE is_ys.user.user_id = is_ys.order.user_id AND is_ys.restaurant.restaurant_id = is_ys.order.restaurant_id AND is_ys.user.user_id = 43
ORDER BY is_ys.order.order_dt DESC
LIMIT 5)
UNION ALL
(SELECT is_ys.user.user_id,is_ys.user.user_fn, is_ys.user.user_ln, is_ys.restaurant.restaurant_name, is_ys.order.order_dt
FROM is_ys.user, is_ys.restaurant, is_ys.order
WHERE is_ys.user.user_id = is_ys.order.user_id AND is_ys.restaurant.restaurant_id = is_ys.order.restaurant_id AND is_ys.user.user_id = 44
ORDER BY is_ys.order.order_dt DESC
LIMIT 5)
UNION ALL
(SELECT is_ys.user.user_id,is_ys.user.user_fn, is_ys.user.user_ln, is_ys.restaurant.restaurant_name, is_ys.order.order_dt
FROM is_ys.user, is_ys.restaurant, is_ys.order
WHERE is_ys.user.user_id = is_ys.order.user_id AND is_ys.restaurant.restaurant_id = is_ys.order.restaurant_id AND is_ys.user.user_id = 45
ORDER BY is_ys.order.order_dt DESC
LIMIT 5)
UNION ALL
(SELECT is_ys.user.user_id,is_ys.user.user_fn, is_ys.user.user_ln, is_ys.restaurant.restaurant_name, is_ys.order.order_dt
FROM is_ys.user, is_ys.restaurant, is_ys.order
WHERE is_ys.user.user_id = is_ys.order.user_id AND is_ys.restaurant.restaurant_id = is_ys.order.restaurant_id AND is_ys.user.user_id = 46
ORDER BY is_ys.order.order_dt DESC
LIMIT 5)
UNION ALL
(SELECT is_ys.user.user_id,is_ys.user.user_fn, is_ys.user.user_ln, is_ys.restaurant.restaurant_name, is_ys.order.order_dt
FROM is_ys.user, is_ys.restaurant, is_ys.order
WHERE is_ys.user.user_id = is_ys.order.user_id AND is_ys.restaurant.restaurant_id = is_ys.order.restaurant_id AND is_ys.user.user_id = 47
ORDER BY is_ys.order.order_dt DESC
LIMIT 5)
UNION ALL
(SELECT is_ys.user.user_id,is_ys.user.user_fn, is_ys.user.user_ln, is_ys.restaurant.restaurant_name, is_ys.order.order_dt
FROM is_ys.user, is_ys.restaurant, is_ys.order
WHERE is_ys.user.user_id = is_ys.order.user_id AND is_ys.restaurant.restaurant_id = is_ys.order.restaurant_id AND is_ys.user.user_id = 48
ORDER BY is_ys.order.order_dt DESC
LIMIT 5)
UNION ALL
(SELECT is_ys.user.user_id,is_ys.user.user_fn, is_ys.user.user_ln, is_ys.restaurant.restaurant_name, is_ys.order.order_dt
FROM is_ys.user, is_ys.restaurant, is_ys.order
WHERE is_ys.user.user_id = is_ys.order.user_id AND is_ys.restaurant.restaurant_id = is_ys.order.restaurant_id AND is_ys.user.user_id = 49
ORDER BY is_ys.order.order_dt DESC
LIMIT 5)
UNION ALL
(SELECT is_ys.user.user_id,is_ys.user.user_fn, is_ys.user.user_ln, is_ys.restaurant.restaurant_name, is_ys.order.order_dt
FROM is_ys.user, is_ys.restaurant, is_ys.order
WHERE is_ys.user.user_id = is_ys.order.user_id AND is_ys.restaurant.restaurant_id = is_ys.order.restaurant_id AND is_ys.user.user_id = 50
ORDER BY is_ys.order.order_dt DESC
LIMIT 5)
UNION ALL
(SELECT is_ys.user.user_id,is_ys.user.user_fn, is_ys.user.user_ln, is_ys.restaurant.restaurant_name, is_ys.order.order_dt
FROM is_ys.user, is_ys.restaurant, is_ys.order
WHERE is_ys.user.user_id = is_ys.order.user_id AND is_ys.restaurant.restaurant_id = is_ys.order.restaurant_id AND is_ys.user.user_id = 51
ORDER BY is_ys.order.order_dt DESC
LIMIT 5)
UNION ALL
(SELECT is_ys.user.user_id,is_ys.user.user_fn, is_ys.user.user_ln, is_ys.restaurant.restaurant_name, is_ys.order.order_dt
FROM is_ys.user, is_ys.restaurant, is_ys.order
WHERE is_ys.user.user_id = is_ys.order.user_id AND is_ys.restaurant.restaurant_id = is_ys.order.restaurant_id AND is_ys.user.user_id = 52
ORDER BY is_ys.order.order_dt DESC
LIMIT 5)UNION ALL
(SELECT is_ys.user.user_id,is_ys.user.user_fn, is_ys.user.user_ln, is_ys.restaurant.restaurant_name, is_ys.order.order_dt
FROM is_ys.user, is_ys.restaurant, is_ys.order
WHERE is_ys.user.user_id = is_ys.order.user_id AND is_ys.restaurant.restaurant_id = is_ys.order.restaurant_id AND is_ys.user.user_id = 53
ORDER BY is_ys.order.order_dt DESC
LIMIT 5)
UNION ALL
(SELECT is_ys.user.user_id,is_ys.user.user_fn, is_ys.user.user_ln, is_ys.restaurant.restaurant_name, is_ys.order.order_dt
FROM is_ys.user, is_ys.restaurant, is_ys.order
WHERE is_ys.user.user_id = is_ys.order.user_id AND is_ys.restaurant.restaurant_id = is_ys.order.restaurant_id AND is_ys.user.user_id = 54
ORDER BY is_ys.order.order_dt DESC
LIMIT 5)
UNION ALL
(SELECT is_ys.user.user_id,is_ys.user.user_fn, is_ys.user.user_ln, is_ys.restaurant.restaurant_name, is_ys.order.order_dt
FROM is_ys.user, is_ys.restaurant, is_ys.order
WHERE is_ys.user.user_id = is_ys.order.user_id AND is_ys.restaurant.restaurant_id = is_ys.order.restaurant_id AND is_ys.user.user_id = 55
ORDER BY is_ys.order.order_dt DESC
LIMIT 5)
UNION ALL
(SELECT is_ys.user.user_id,is_ys.user.user_fn, is_ys.user.user_ln, is_ys.restaurant.restaurant_name, is_ys.order.order_dt
FROM is_ys.user, is_ys.restaurant, is_ys.order
WHERE is_ys.user.user_id = is_ys.order.user_id AND is_ys.restaurant.restaurant_id = is_ys.order.restaurant_id AND is_ys.user.user_id = 56
ORDER BY is_ys.order.order_dt DESC
LIMIT 5)
UNION ALL
(SELECT is_ys.user.user_id,is_ys.user.user_fn, is_ys.user.user_ln, is_ys.restaurant.restaurant_name, is_ys.order.order_dt
FROM is_ys.user, is_ys.restaurant, is_ys.order
WHERE is_ys.user.user_id = is_ys.order.user_id AND is_ys.restaurant.restaurant_id = is_ys.order.restaurant_id AND is_ys.user.user_id = 57
ORDER BY is_ys.order.order_dt DESC
LIMIT 5)
UNION ALL
(SELECT is_ys.user.user_id,is_ys.user.user_fn, is_ys.user.user_ln, is_ys.restaurant.restaurant_name, is_ys.order.order_dt
FROM is_ys.user, is_ys.restaurant, is_ys.order
WHERE is_ys.user.user_id = is_ys.order.user_id AND is_ys.restaurant.restaurant_id = is_ys.order.restaurant_id AND is_ys.user.user_id = 58
ORDER BY is_ys.order.order_dt DESC
LIMIT 5)
UNION ALL
(SELECT is_ys.user.user_id,is_ys.user.user_fn, is_ys.user.user_ln, is_ys.restaurant.restaurant_name, is_ys.order.order_dt
FROM is_ys.user, is_ys.restaurant, is_ys.order
WHERE is_ys.user.user_id = is_ys.order.user_id AND is_ys.restaurant.restaurant_id = is_ys.order.restaurant_id AND is_ys.user.user_id = 59
ORDER BY is_ys.order.order_dt DESC
LIMIT 5)
