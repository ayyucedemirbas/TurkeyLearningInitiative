SELECT distinct(is_ys.user.user_id),is_ys.user.user_fn,is_ys.user.user_ln
FROM is_ys.restaurant,is_ys.order,is_ys.user
WHERE is_ys.order.user_id IN (SELECT is_ys.restaurant.owner_id
						FROM is_ys.restaurant,is_ys.order
						WHERE is_ys.restaurant.restaurant_id=is_ys.order.restaurant_id)
AND is_ys.order.user_id=is_ys.user.user_id
