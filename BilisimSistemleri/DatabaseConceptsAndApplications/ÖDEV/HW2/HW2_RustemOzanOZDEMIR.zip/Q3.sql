SELECT is_ys.restaurant.restaurant_id, is_ys.restaurant.restaurant_name, is_ys.restaurant.cuisine, count(order_id) as numberoforders
FROM is_ys.order NATURAL JOIN is_ys.restaurant
WHERE is_ys.restaurant.restaurant_id IN 
										(SELECT is_ys.review.restaurant_id
										FROM is_ys.review JOIN is_ys.response 
										ON is_ys.review.restaurant_id=is_ys.response.restaurant_id
										WHERE is_ys.review.restaurant_id=is_ys.restaurant.restaurant_id
										GROUP BY is_ys.review.restaurant_id
										HAVING COUNT(DISTINCT is_ys.review.review_dt)/2 < COUNT(DISTINCT is_ys.response.response_dt))
GROUP BY is_ys.restaurant.restaurant_id
ORDER BY numberoforders DESC
lIMIT 5