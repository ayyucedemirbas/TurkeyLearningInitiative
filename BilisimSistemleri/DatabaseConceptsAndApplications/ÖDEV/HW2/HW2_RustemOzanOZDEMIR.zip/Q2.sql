SELECT distinct(WORKINGDAY.restaurant_id), restaurant.restaurant_name, restaurant.cuisine,location.location_id, location.neighborhood, location.district, location.city
FROM (SELECT PRICEDAY.*
FROM (SELECT is_ys.working_hours.restaurant_id
      FROM is_ys.working_hours
      GROUP BY is_ys.working_hours.restaurant_id
      HAVING count(is_ys.working_hours.day_id) < 7
	 )WORKDAY JOIN
	 (SELECT  restaurant_id, user_id, order_id, order_dt, sum(quantity * item_price) as totalprice
	  FROM (SELECT is_ys.order.*,is_ys.menu_item.item_price
FROM is_ys.order JOIN is_ys.menu_item
ON is_ys.order.restaurant_id = is_ys.menu_item.restaurant_id AND is_ys.order.item_id = is_ys.menu_item.item_id) AS PRICEORDER
	  WHERE order_dt >= "2019-10-30 00:00:00" AND order_dt >= "2019-11-01" AND cancelled = 0
	  GROUP BY  restaurant_id, user_id, order_id, order_dt
	  HAVING count(totalprice > 50) < 10
	 )PRICEDAY
ON WORKDAY.restaurant_id = PRICEDAY.restaurant_id) AS WORKINGDAY ,restaurant, location
WHERE restaurant.restaurant_id = WORKINGDAY.restaurant_id AND restaurant.location_id = location.location_id