SELECT is_ys.user.user_id,is_ys.user.user_fn,is_ys.user.user_ln
FROM is_ys.user
WHERE NOT EXISTS (SELECT *
				  FROM is_ys.restaurant
                  WHERE is_ys.restaurant.restaurant_id in (2,3) AND
						NOT EXISTS (SELECT *
									FROM is_ys.review
									WHERE is_ys.review.user_id = is_ys.user.user_id AND is_ys.review.restaurant_id = is_ys.restaurant.restaurant_id)) AND
									is_ys.user.user_id NOT IN (SELECT is_ys.review.user_id 
									FROM is_ys.review,is_ys.restaurant
									WHERE is_ys.review.restaurant_id = is_ys.restaurant.restaurant_id AND is_ys.restaurant.cuisine ="Turkish" )