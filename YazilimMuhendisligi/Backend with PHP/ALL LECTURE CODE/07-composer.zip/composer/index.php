<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0"/>
    <title>Title of the document</title>
    <link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/materialize/1.0.0/css/materialize.min.css">
    <script src="https://code.jquery.com/jquery-3.2.1.min.js" integrity="sha256-hwg4gsxgFZhOsEEamdOYGBf13FyQuiTwlAQgxVSNgt4=" crossorigin="anonymous"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/materialize/1.0.0/js/materialize.min.js"></script>
    <style>
    </style>
  </head>
  <body>
   <?php
      require_once './vendor/autoload.php' ;

      //$ip = $_SERVER["REMOTE_ADDR"] ;
      $ip = "amazon.de" ;

      $httpClient = new \GuzzleHttp\Client(["verify" => false]);
      $response = $httpClient->request('GET', 'https://freegeoip.app/json/' . $ip);
      $location = json_decode($response->getBody()->getContents()) ; 
     // var_dump($location) ;

      $response = $httpClient->request('GET', 'https://restcountries.eu/rest/v2/name/' . $location->country_name);
      $country = json_decode($response->getBody()->getContents())[0] ; 
     // var_dump($country) ;

   ?>
   <div class="container">
   <p>Do not forget to update email account information</p>
   <table>
     <tr>
         <th>Flag</th>
         <th>IP</th>
         <th>Country</th>
         <th>Capital</th>
         <th>City</th>
         <th>Location</th>
     </tr>
     <tr>
         <td><img width="45" src="<?= $country->flag ?>" /></td>
         <td><?= $location->ip ?></td>
         <td><?= $location->country_name ?></td>
         <td><?= $country->capital ?></td>
         <td><?= $location->city ?></td>
         <td><?= $location->longitude . "/" . $location->latitude ?></td>
     </tr>
   </table>
   
   </div>


   <?php
    use PHPMailer\PHPMailer\PHPMailer;
    use PHPMailer\PHPMailer\SMTP;
    use PHPMailer\PHPMailer\Exception;
    
    //Instantiation and passing `true` enables exceptions
    $mail = new PHPMailer(true);
    
    require "../pass.php" ;

    try {
        //Server settings
        $mail->isSMTP();                                            //Send using SMTP
        $mail->Host       = 'asmtp.bilkent.edu.tr';                     //Set the SMTP server to send through
        $mail->SMTPAuth   = true;                                   //Enable SMTP authentication
        $mail->Username   = 'youraccount@bilkent.edu.tr';                     //SMTP username
        $mail->Password   = 'your password';                               //SMTP password
        $mail->SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS;         //Enable TLS encryption; `PHPMailer::ENCRYPTION_SMTPS` encouraged
        $mail->Port       = 587;                                    //TCP port to connect to, use 465 for `PHPMailer::ENCRYPTION_SMTPS` above
    
        //Recipients
        $mail->setFrom('youraccount@bilkent.edu.tr', 'CTIS256 - App');
        $mail->addAddress('To_email', 'To Name Surname');     //Add a recipient
        //Content
        $mail->isHTML(true);                                  //Set email format to HTML
        $mail->Subject = 'A visitor detected';
        $mail->Body    = 'A visitor from ' . $location->ip . ' in <b>' . $location->country_name . "</b>";
    
        $mail->send();
        echo 'Message has been sent to Administrator';
    } catch (Exception $e) {
        echo "Message could not be sent. Mailer Error: {$mail->ErrorInfo}";
    }

  ?>

  
  </body>
</html>