<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0"/>
    <title>Title of the document</title>
    <link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/materialize/1.0.0/css/materialize.min.css">
    <script src="https://code.jquery.com/jquery-3.2.1.min.js" integrity="sha256-hwg4gsxgFZhOsEEamdOYGBf13FyQuiTwlAQgxVSNgt4=" crossorigin="anonymous"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/materialize/1.0.0/js/materialize.min.js"></script>
    <style>
    </style>
  </head>
  <body>
   <div class="container">
   <?php

     // auto load classes
     spl_autoload_register(function($class){
      //  echo $class ;
         require_once './' . $class . '.php' ;
     });
    
     //require_once './App/Classes/User.php' ;
     //require_once './App/Classes/Student.php' ;
     
     use App\Classes as A ;  // A is an alias to App\Classes

     $p1 = new App\Classes\User("Mine Kaval", App\Classes\User::FEMALE) ; // :: scope operator means within
     $p2 = new A\User("Ali Gül", A\User::MALE) ;
     $std = new A\Student("Özge Şener", A\User::FEMALE, 123456) ;

     echo "<p>", $p1->display(), "</p>" ;
     echo "<p>", $p2->display(), "</p>" ;
     echo "<p>", $std->display(), "</p>" ;

     echo "<p>", A\User::getCount() , "</p>" ; // accessing static/class property

     // polymorphism
     $list = [$p1, $p2, $std] ; // $list is a polymorphic array. 

     // what is the type of obj?? it may be User or Student
     // $obj is a polymorphic variable.
     foreach( $list as $obj) {
         echo "<p>", $obj->display() , "</p>" ;
     }
     
   ?>
   
   </div>

  </body>
</html>