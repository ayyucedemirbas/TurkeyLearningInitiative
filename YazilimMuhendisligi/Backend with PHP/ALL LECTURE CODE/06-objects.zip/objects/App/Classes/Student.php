<?php
  namespace App\Classes ; 
  
  require_once "User.php" ;

  class Student extends User {
      
    private $id ;
    
    public function __construct($fullname, $gender, $id)
    {
        parent::__construct($fullname, $gender) ;
        $this->id = $id ;
    }

    public function display() {
        $result = parent::display() ; // it returns fullname and gender string.
        return $result . "  ID : {$this->id}" ;
    }


  }