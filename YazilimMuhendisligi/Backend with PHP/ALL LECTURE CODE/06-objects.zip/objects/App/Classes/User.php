<?php
  namespace App\Classes ; 

// Encapsulation, Information Hiding, Inheritance, Polymorhism

class User {

    // instance properties.
    protected $fullname, $gender ;

    // instance methods
    public function __construct($fullname, $gender)
    {
        $this->fullname = $fullname ;
        $this->gender = $gender ;

        self::$count++ ;
    }

    public function display() {
        return "Username: {$this->fullname}, Gender: " 
              . ($this->gender === self::MALE ? "MALE" : "FEMALE" ) ;
    }

    // class constants
    const MALE = 1 ;
    const FEMALE = 2 ; 

    // class properties
    private static $count = 0 ; 

    // class method
    public static function getCount() {
        return self::$count ; 
    }

}
