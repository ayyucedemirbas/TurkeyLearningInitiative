<?php
   // var_dump($_POST) ;
   if ( !empty($_POST)) {
      extract($_POST) ;

      $error = [] ;

      // Bilkent ID
      $re = '/^2\d{7}$/' ;
      if ( preg_match($re, $bilkent) === 0) {
        $error[] = "bilkent" ;
      }

      // Password  \s : all whitespace chars.  \S : non-whitespace chars.
      $re = '/^\S{6,12}$/' ;
      if ( preg_match($re, $pass) === 0) {
        $error[] = "pass" ;
      }

      // Image Filename
      $re = '/^\w+\.(?:jpg|png)$/iu' ;
      if ( preg_match($re, $image) === 0) {
        $error[] = "image" ;
      }

      // Hex Color Code
      $re = '/^#[0-9a-f]{3}(?:[0-9a-f]{3})?$/i' ;
      if ( preg_match($re, $color) === 0) {
        $error[] = "color" ;
      }

      // Parse email addresses in free text.
      $re = '/(\w+)@((?:\w+\.){1,3}(?:com|tr))/iu' ;
      preg_match_all($re, $email, $result) ;
   }

   // $error exists, this means this file is requested by POST method.
   // if it exists, check the specific field within $error array.
?>

<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0"/>
    <title>Title of the document</title>
    <link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/materialize/1.0.0/css/materialize.min.css">
    <script src="https://code.jquery.com/jquery-3.2.1.min.js" integrity="sha256-hwg4gsxgFZhOsEEamdOYGBf13FyQuiTwlAQgxVSNgt4=" crossorigin="anonymous"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/materialize/1.0.0/js/materialize.min.js"></script>
    <style>
      td:first-of-type { width: 80% ;}
    </style>
  </head>
  <body>
  <div class="container">
  <h5 class="center">Regular Expression</h5>
  <form action="" method="post">
    <table class="striped">
      <tr>
          <td>
            <div class="input-field">
              <input name="bilkent" id="bilkent" type="text" class="validate"
              value="<?= $bilkent ?? '' ?>"
              >
              <label for="bilkent">Bilkent ID</label>
            </div>
          </td>
          <td>
           <?php
             if ( isset($error)) {
               echo in_array("bilkent", $error) ? "INVALID" : "VALID" ;
             }
           ?>
          </td>
      </tr>
      <tr>
          <td>
            <div class="input-field">
              <input name="pass" id="pass" type="text" class="validate" 
              value="<?= $pass ?? '' ?>"
              >
              <label for="pass">Password</label>
            </div>
          </td>
          <td>
          <?php
             if ( isset($error)) {
               echo in_array("pass", $error) ? "INVALID" : "VALID" ;
             }
           ?>
          </td>
      </tr>
      <tr>
          <td>
            <div class="input-field">
              <input name="image" id="image" type="text" class="validate"
              value="<?= $image ?? '' ?>"
              >
              <label for="image">Image Filename</label>
            </div>
          </td>
          <td>
          <?php
             if ( isset($error)) {
               echo in_array("image", $error) ? "INVALID" : "VALID" ;
             }
           ?>
          </td>
      </tr>
      <tr>
          <td>
            <div class="input-field">
              <input name="color" id="color" type="text" class="validate"
              value="<?= $color ?? '' ?>"
              >
              <label for="color">Color Code</label>
            </div>
          </td>
          <td>
          <?php
             if ( isset($error)) {
               echo in_array("color", $error) ? "INVALID" : "VALID" ;
             }
           ?>
          </td>
      </tr>
      <tr>
          <td colspan="2">
            <div class="input-field">
              <textarea name="email" id="email" class="materialize-textarea"><?= $email ?? '' ?></textarea>
              <label for="email">Parse Emails</label>
            </div>
          </td>
      </tr>
      <tr>
          <td colspan="2">
            <button class="btn waves-effect waves-light" type="submit" name="action">Validate
              <i class="material-icons right">send</i>
            </button>
          </td>
      </tr>
    </table>
    <p>
      <?php
          if ( !empty($result[0])) {
            echo "<p>Emails (full) : " , join(" , ", $result[0]), "</p>" ;
            echo "<p>Emails (user) : " , join(" , ", $result[1]), "</p>" ;
            echo "<p>Emails (domain) : " , join(" , ", $result[2]), "</p>" ;
          }
      ?>
    </p>
  </form>
  </div>
  </body>
</html>